assets/css
===========

This is for module specific styling

assets/js
==========
This is for module specific Java script.


Javascript Libraries
====================

The following libraries are built in already and can be used without inclusion.


 - jquery-1.6.2.min.js
 - jquery-1.7.1.min.js
 - jquery-ui-1.8.16.min.js
 - jquery-ui-1.8.9.min.js
 - jquery.cookie.js
 - jquery.hotkeys.js
 - jquery.toggleval.3.0.js
