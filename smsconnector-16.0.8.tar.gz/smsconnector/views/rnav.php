<?php if (!defined('FREEPBX_IS_AUTH')) { die('No direct script access allowed'); } ?>
<br>
<div class="list-group">
	<a href='?display=smsconnector' class="list-group-item"><i class="fa fa-list"></i>&nbsp;&nbsp;&nbsp;<?php echo _('List Numbers')?></a>
	<a href='?display=smsconnector&amp;view=settings' class="list-group-item"><i class="fa fa-cog"></i>&nbsp;&nbsp;&nbsp;<?php echo _('Provider Settings')?></a>
</div>