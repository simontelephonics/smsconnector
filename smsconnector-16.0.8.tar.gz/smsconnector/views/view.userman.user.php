<?php
    echo sprintf('<p>%s<a href="/admin/config.php?display=smsconnector">%s</a></p>', _('Not yet implemented.'), _('Go to SMS Connector.'));
?>