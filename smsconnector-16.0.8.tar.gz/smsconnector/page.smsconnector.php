<?php
echo FreePBX::create()->Smsconnector->showPage('main');
